Original code was forked from kalterfive, and had been released under GPL3.

  Copyright (C) 2016 kalterfive
  This file is part of ipshower@kalterfx-gmail.com"
